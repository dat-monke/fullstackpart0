# CSS Basics

Tags: Part 0
Type: Assignment, Information

# What is CSS?

---

<aside>
💡 CSS stands for Cascading Style Sheets

</aside>

## Anatomy of a CSS ruleset

---

- It is a style sheet language, all it does is change the way it looks

```css
p {
  color: red;
}
```

- `p` - Selector is the start of the ruleset
- `{}` - Declaration, this is made up of the property and the property value
- `<color>` - Property, this is what you want to change
- `<red>` - Property Value, this is what to change it to

### Selecting Multiple Elements

---

```css
p,
li,
h1 {
  color: red;
}
```

- You can add commas to add multiple elements to apply the changes to

### Different types of selectors

---

| Selector name | What does it select | Example |
| --- | --- | --- |
| Element selector (sometimes called a tag or type selector) | All HTML elements of the specified type. | pselects <p> |
| ID selector | The element on the page with the specified ID. On a given HTML page, each id value should be unique. | #my-idselects <p id="my-id"> or <a id="my-id"> |
| Class selector | The element(s) on the page with the specified class. Multiple instances of the same class can appear on a page. | .my-classselects <p class="my-class"> and <a class="my-class"> |
| Attribute selector | The element(s) on the page with the specified attribute. | img[src]selects <img src="myimage.png"> but not <img> |
| Pseudo-class selector | The specified element(s), but only when in the specified state. (For example, when a cursor hovers over a link.) | a:hoverselects <a>, but only when the mouse pointer is hovering over the link. |

## Fonts and text

---

- These changes will take place in the `style.css` file

```css
<link
  href="https://fonts.googleapis.com/css?family=Open+Sans"
  rel="stylesheet" />
```

1. Find the font that you would like from Google Fonts 
2. Create a `<link>` tag that will be placed between the `<head></head>` tags 
3. Edit the existing rule located in the file `style.css`
4. Add the font-family selection code in the document 
    
    ```css
    html {
      font-size: 10px; /* px means "pixels": the base font size is now 10 pixels high */
      font-family: "Open Sans", sans-serif; /* this should be the rest of the output you got from Google Fonts */
    }
    ```
    
5. Then set the font sizing for all the other elements 
    
    ```css
    h1 {
      font-size: 60px;
      text-align: center;
    }
    
    p,
    li {
      font-size: 16px;
      line-height: 2;
      letter-spacing: 1px;
    }
    ```
    

## CSS: all about boxes

---

- The most common ‘box’ layout is as follows:
    - `padding` - This is the space around the content
    - `border` - This is the solid line just outside the padding
    - `margin` - This is the space around the outside of the border
    - Image reference
        
        ![Untitled](CSS%20Basics%20b8cac9502aac40c490e9c0e1e3154d6c/Untitled.png)
        
    - Other attributes:
        - `width`
        - `background-color` - The color behind the content and padding
        - `color` - The color of the content/text
        - `text-shadow` - The shadow of the text in the element
        - `display` - The display mode of the element

### Changing the page color

---

```css
html {
  background-color: #00539f;
}
```

- This sets the background for your whole page

### Styling the body

---

```css
body {
  width: 600px;
  margin: 0 auto;
  background-color: #ff9500;
  padding: 0 20px 20px 20px;
  border: 5px solid black;
}
```

- `width: 600px;` This sets it to 600 pixels
- `margin: 0 auto;` The first value is for top and bottom, the second value is the left and right side margin/padding. You can also use one, two, three, or four values (for each side)
- `background-color: #FF9500;` This sets the element's background color
- `padding: 0 20px 20px 20px;` This follows the same arguments as margin
- `border: 5px solid black;` This sets values for the width, style and color of the border

### Positioning and styling the main page title

---

```css
h1 {
  margin: 0;
  padding: 20px 0;
  color: #00539f;
  text-shadow: 3px 3px 1px black;
}
```

- The reason why you sometimes see weird gaps between the body and the header is due to the `<h1>` element not having this setting `margin: 0;`
- Padding and color we have discussed above
- `text-shadow: 3px 3px 1px black;` This first value is the horizontal offset, the second is vertical offset, third is the blur on the shadow, the fourth is the base color of the shadow

### Centering the image

---

```css
img {
  display: block;
  margin: 0 auto;
}
```

- `<body>` is a block element which means it uses space on a page, if we were to use margin it would require it to be a block → `display: block;`
- If the image is bigger than the width of the page:
    - Reduce the image size
    - Use CSS to resize the image/set the `width` property on the `<img>` element