# HTML Basics

Tags: Part 0
Type: Assignment, Information

# What is HTML?

---

<aside>
💡 HTML stands for HyperText Markup Language

</aside>

## Anatomy of HTML Elements

---

```html
<p>My cat is very grumpy</p> 

<p class="editor-note">My cat is very grumpy</p> 
```

- `<p>` is the opening tag
- `</p>` is the closing tag
- The content is what is in between the tags
- The element is everything combined
- `<p class=”…”>` is an attribute

### Nesting Elements

---

```html
<p>My cat is <strong>very</strong> grumpy.</p> 
```

- An important note is to close the element in the order that they are opened

### Void Elements

---

```html
<img src="images/firefox-icon.png" alt="My test image" /> 
```

- Here there are two attributes, but there is not closing `</img>` tag since there is nothing to be wrapped inside, it will appear when it is rendered/called

## Anatomy of an HTML Document

---

```html
<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width" />
    <title>My test page</title>
  </head>
  <body>
    <img src="images/firefox-icon.png" alt="My test image" />
  </body>
</html>
```

- `<!DOCTYPE html>` is a required part and just makes sure everything behaves correctly\
- `<html></html>` wraps all the content together including the the lang attribute
- `<head></head>` is an element that is a container for all the stuff you want on your page
    - Includes: Keywords, page descriptions, CSS, character set declarations, etc
- `<meta charset=”utf-8”>` is a character set (most common set and should always be set)
- `<meta name=”viewport” content=”width=device-width”>` prevents mobile devices from rendering pages bigger than the screen and shrinks it down to the size
- `<title></title>` is the title of the page that you see on the browser tab and bookmarks
- `<body></body>` is all the content that you want to show to your audience

## Images

---

```html
<img src="images/firefox-icon.png" alt="My test image" />
```

- It is important to have an alt text defined since it has two main use cases
    - For the visually impaired, the screen reader will read out the alt text to them
    - Image not rendering; it will display the text instead of the image
- The alt text should always be as descriptive as possible
    - Example: “The Firefox logo: a flaming fox surrounding the Earth.”

## Marking up text

---

### Headings

---

```html
<!-- 4 heading levels: -->
<h1>My main title</h1>
<h2>My top level heading</h2>
<h3>My subheading</h3>
<h4>My sub-subheading</h4>
```

- There is technically up to 6 headings, but it is most common to only use up to the first 4
- When you define the headings, they should not be just to make the text bigger or bold, it has impact on accessibility and also SEO

### Paragraphs

---

```html
<p>This is a single paragraph</p>
```

- Most common use is just to make regular text content

### Lists

---

- There are two main types of lists:
    - Unordered lists: This is wrapped in `<ul>`
    - Ordered lists: This is wrapped in `<ol>`

```html
<p>At Mozilla, we're a global community of</p>

<ul>
  <li>technologists</li>
  <li>thinkers</li>
  <li>builders</li>
</ul>

<p>working together…</p>
```

## Links

---

- The element to create a link is `<a>` which stands for ‘anchor’
- Steps to create a paragraph link:
    
    ```html
    <p>Mozilla Manifesto</p> 
    
    <a>Mozilla Manifesto</a>
    
    <a href="">Mozilla Manifesto</a>
    
    <a href="https://www.mozilla.org/en-US/about/manifesto/">Mozilla Manifesto</a>
    ```
    
- Make sure to include https:// or http:// else it may not work correctly